import { MAX_BODY_BYTES, parseInquiry } from "./validate";
import { sendToFormSubmit, type SendOptions, type SendOutcome } from "./send";

export type InquiryResponse = {
  ok: boolean;
  message: string;
  code?: string;
  /** True only when the request provably never left the server, so one client-side retry is safe. */
  retrySafe?: boolean;
  /** Direct browser endpoint, supplied only together with retrySafe. */
  fallbackEndpoint?: string;
};

type HandlerConfig = {
  endpoint: string;
  /** Allow the browser to try FormSubmit directly once when the server could not reach it. */
  allowBrowserFallback?: boolean;
  send?: (endpoint: string, payload: Record<string, string>, origin: string, options?: SendOptions) => Promise<SendOutcome>;
  sendOptions?: SendOptions;
  log?: (entry: Record<string, unknown>) => void;
};

const CONTACT_DIRECTLY = "contact us directly";

function json(body: InquiryResponse, status: number): Response {
  return Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

/** Builds the POST handler for /api/inquiries. Kept out of route.ts so it can be tested and reused. */
export function createInquiryHandler({
  endpoint,
  allowBrowserFallback = true,
  send = sendToFormSubmit,
  sendOptions,
  log = (entry) => console.error("[inquiries]", entry),
}: HandlerConfig) {
  return async function POST(request: Request): Promise<Response> {
    const declaredLength = Number(request.headers.get("content-length") ?? 0);
    if (declaredLength > MAX_BODY_BYTES) {
      return json({ ok: false, code: "TOO_LARGE", message: "Your message is too long. Please shorten it and try again." }, 413);
    }

    let body: unknown;
    try {
      const text = await request.text();
      if (text.length > MAX_BODY_BYTES) {
        return json({ ok: false, code: "TOO_LARGE", message: "Your message is too long. Please shorten it and try again." }, 413);
      }
      body = JSON.parse(text);
    } catch {
      return json({ ok: false, code: "INVALID_BODY", message: "Please check your details and try again." }, 400);
    }

    const parsed = parseInquiry(body);
    if (!parsed.ok) return json({ ok: false, code: parsed.code, message: parsed.message }, 400);
    // Bots only: a hidden field was filled in. Acknowledge without forwarding.
    if (parsed.honeypot) return json({ ok: true, message: "Thank you! Your inquiry has been sent." }, 200);

    const payload = { ...parsed.fields, _subject: parsed.subject, _template: "table", _captcha: "false" };
    const origin = new URL(request.url).origin;
    const outcome = await send(endpoint, payload, origin, sendOptions);

    switch (outcome.kind) {
      case "accepted":
        return json({ ok: true, message: "Thank you! Your inquiry has been sent. We’ll be in touch soon." }, 200);

      case "activation":
        log({ kind: outcome.kind });
        return json(
          { ok: false, code: "ACTIVATION_REQUIRED", message: `Our inquiry form isn’t fully set up yet, so your message was not delivered. Please ${CONTACT_DIRECTLY}.` },
          503,
        );

      case "rejected":
        log({ kind: outcome.kind, status: outcome.status, detail: outcome.detail });
        return json(
          { ok: false, code: "UPSTREAM_REJECTED", message: `The email service didn’t accept your inquiry. Please try again shortly or ${CONTACT_DIRECTLY}.` },
          502,
        );

      case "malformed":
        log({ kind: outcome.kind, status: outcome.status });
        return json(
          { ok: false, code: "UPSTREAM_INVALID_RESPONSE", message: `The email service gave an unexpected reply. Please try again shortly or ${CONTACT_DIRECTLY}.` },
          502,
        );

      case "unreachable":
        log({ kind: outcome.kind, code: outcome.code });
        return json(
          {
            ok: false,
            code: "UPSTREAM_UNREACHABLE",
            message: `We couldn’t reach the email service. Please try again shortly or ${CONTACT_DIRECTLY}.`,
            retrySafe: true,
            ...(allowBrowserFallback ? { fallbackEndpoint: endpoint } : {}),
          },
          503,
        );

      case "timeout":
        log({ kind: outcome.kind });
        return json(
          {
            ok: false,
            code: "UPSTREAM_TIMEOUT",
            message: `The email service is taking too long to answer, so we can’t confirm your message was delivered. Please don’t resubmit; ${CONTACT_DIRECTLY} to be sure.`,
          },
          504,
        );

      default:
        log({ kind: outcome.kind, code: outcome.code });
        return json(
          { ok: false, code: "UPSTREAM_NETWORK_ERROR", message: `The connection to the email service was interrupted, so we can’t confirm delivery. Please don’t resubmit; ${CONTACT_DIRECTLY} to be sure.` },
          502,
        );
    }
  };
}
